Le programme est en une seule fenêtre console.

Pour le serveur, lancer directement. La commande \quit entrée au clavier éteint le serveur.

Pour le client, lancer avec le nom de l'hôte, choisir un pseudo (celui de la machine par défaut), puis taper les messages au clavier.
Commande \quit également.

Bugs : le pseudo est vide au niveau de la déconnexion d'un client (serveur), le premier message de chaque client est remplacé par un \n, sûrement des problème de vidage de buffer...
